# Tech Stocks Dataset (2010-2024)

## Dataset Description
This dataset contains comprehensive daily stock market data for five major technology companies (AAPL, MSFT, NVDA, GOOG, TSLA) from January 2010 through December 2024. The data was collected using Yahoo Finance API and includes price data, technical indicators, and related macroeconomic variables.

## Data Sources
- Primary source: Yahoo Finance API (https://finance.yahoo.com/)
- We thank Yahoo Finance for providing the market data used in this compilation

## Files Included
- `AAPL.csv`: Apple Inc. stock data
- `MSFT.csv`: Microsoft Corporation stock data  
- `NVDA.csv`: NVIDIA Corporation stock data
- `GOOG.csv`: Alphabet Inc. stock data
- `TSLA.csv`: Tesla Inc. stock data

## Data Fields
Each file contains these key fields (where XX represents the stock ticker):

### Price Data
- `XX_close`: Daily closing price
- `XX_high`: Daily high price  
- `XX_low`: Daily low price
- `XX_volume`: Trading volume

### Technical Indicators
- `XX_ma_20`: 20-day moving average
- `XX_ma_50`: 50-day moving average
- `XX_rsi`: 14-day Relative Strength Index  
- `XX_volatility`: 20-day price volatility

### Macroeconomic Indicators (common across all files)
- `sp500_close`: S&P 500 Index closing value
- `oil_close`: WTI Crude Oil prices
- `treasury_10y_close`: 10-year Treasury yield

## Data Processing

### Missing Value Treatment
The dataset employs rigorous missing data handling:

1. **Initial Cleaning**:
   - Dropped columns with >30% missing values
   - Removed incomplete trading days (market holidays)

2. **Imputation Methods**:
   - Price data: Time-based linear interpolation
   - Volume data: Zero-filled (assuming no trading activity)
   - Technical indicators: 5-period rolling average imputation

3. **Validation**:
   - Final dataset contains no missing values
   - All time-series maintain consistent continuity

## Usage Example

```python
import pandas as pd

# Load NVIDIA data
nvidia = pd.read_csv('NVDA.csv')

# Calculate 50-day moving average
nvidia['50ma'] = nvidia['nvidia_close'].rolling(50).mean()

# Plot closing price
nvidia.plot(x='date', y='nvidia_close', figsize=(12,6))
